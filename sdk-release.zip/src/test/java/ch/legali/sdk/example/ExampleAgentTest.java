package ch.legali.sdk.example;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExampleAgentTest {

  @Test
  void contextLoads() {
    // Smoke test has passed
  }
}
